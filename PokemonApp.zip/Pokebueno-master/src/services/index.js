import PokeApi from "./PokeApi";
export default PokeApi;
