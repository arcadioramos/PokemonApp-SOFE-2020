import Adoptions from "./Adoptions";
export default Adoptions;
