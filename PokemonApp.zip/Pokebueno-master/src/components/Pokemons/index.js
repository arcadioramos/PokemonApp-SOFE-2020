import Pokemons from "./Pokemons";

export default Pokemons;
